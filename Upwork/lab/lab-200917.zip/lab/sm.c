/**
 * CS2106 AY 20/21 Semester 1 - Lab 2
 *
 * This file contains function definitions. Your implementation should go in
 * this file.
 */

#include "sm.h"
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

sm_status_t processLog[SM_MAX_SERVICES];
#define INITIAL_ARG_SIZE 100

int processCount = 0;

// Use this function to any initialisation if you need to.
void sm_init(void)
{
}

// Use this function to do any cleanup of resources.
void sm_free(void)
{
}

// Exercise 1a/2: start services
void sm_start(const char *processes[])
{
	int pNo = 0, start = 0;
	pid_t pid = -1;
	char **process;
	int prevPipe[2] = {0}, curPipe[2] = {0}, isLast = 0;
	int count = 0, status, num;
	process = (char **)calloc(INITIAL_ARG_SIZE, sizeof(char));

	for (pNo = 0;; pNo++)
	{
		if (processes[pNo] == NULL)
		{
			process[start] = processes[pNo];
			pipe(curPipe);

			if (processes[pNo + 1] == NULL)
				isLast = 1;
			pid = fork();
			if (pid == -1)
			{
				printf("Error starting service!\n");
				return;
			}

			if (pid == 0)
			{ // Child Process Execute
				if (!isLast)
				{
					dup2(curPipe[1], fileno(stdout));
				}
				if (count >= 1)
				{
					dup2(prevPipe[0], fileno(stdin));
					close(prevPipe[0]);
					close(prevPipe[1]);
				}
				else
				{
					close(fileno(stdin));
				}

				execv(process[0], process);
			}
			else
			{
				if (count >= 1)
				{
					close(prevPipe[0]);
					close(prevPipe[1]);
				}

				processLog[processCount].pid = pid;
				processLog[processCount].running = 1;
				processLog[processCount].path = strdup(process[0]);
				processCount++;
				free(process);
				process = (char **)calloc(INITIAL_ARG_SIZE, sizeof(char));
				start = 0;
				count++;
				prevPipe[0] = curPipe[0];
				prevPipe[1] = curPipe[1];
				if (isLast)
				{
					break;
				}
			}
		}
		else
		{
			//Need one extra for NULL which is assigned in above if
			if(start >= (INITIAL_ARG_SIZE - 1)) {
				realloc(process, INITIAL_ARG_SIZE * 2);
			}
			process[start] = processes[pNo];
			start++;
		}
	}
}

// Exercise 1b: print service status
size_t sm_status(sm_status_t statuses[])
{
	int i;
	for (i = 0; i < processCount; i++)
	{
		statuses[i].path = strdup(processLog[i].path);
		statuses[i].pid = processLog[i].pid;
		statuses[i].running = waitpid(processLog[i].pid, NULL, WNOHANG) ? 0 : 1;
	}
	return processCount;
}

// Exercise 3: stop service, wait on service, and shutdown
void sm_stop(size_t index)
{
}

void sm_wait(size_t index)
{
}

void sm_shutdown(void)
{
}

// Exercise 4: start with output redirection
void sm_startlog(const char *processes[])
{
}

// Exercise 5: show log file
void sm_showlog(size_t index)
{
}
