/**
 * CS2106 AY 20/21 Semester 1 - Lab 2
 *
 * This file contains function definitions. Your implementation should go in
 * this file.
 */

#include "sm.h"
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <signal.h>

typedef struct services
{
	sm_status_t *processList;
	int count;
} serviceLog_t;

serviceLog_t serviceList[SM_MAX_SERVICES];
#define INITIAL_ARG_SIZE 100
#define INITIAL_NO_PROCESS 100

int serviceCount = 0;

// Use this function to any initialisation if you need to.
void sm_init(void)
{
}

// Use this function to do any cleanup of resources.
void sm_free(void)
{
	int i = 0;
	for (; i < SM_MAX_SERVICES; i++)
	{
		free(serviceList[i].processList);
	}
}

// Exercise 1a/2: start services
void sm_start(const char *processes[])
{
	int pNo = 0, start = 0;
	pid_t pid = -1;
	char **process;
	int prevPipe[2] = {0}, curPipe[2] = {0}, isLast = 0;
	int processCount = 0, status, num;
	process = (char **)calloc(INITIAL_ARG_SIZE, sizeof(char));
	serviceList[serviceCount].processList = (sm_status_t *)calloc(INITIAL_NO_PROCESS, sizeof(sm_status_t));
	serviceList[serviceCount].count = INITIAL_NO_PROCESS;

	for (pNo = 0;; pNo++)
	{
		if (processes[pNo] == NULL)
		{
			process[start] = processes[pNo];
			pipe(curPipe);

			if (processes[pNo + 1] == NULL)
				isLast = 1;
			pid = fork();
			if (pid == -1)
			{
				printf("Error starting service!\n");
				return;
			}

			if (pid == 0)
			{ // Child Process Execute
				if (!isLast)
				{
					dup2(curPipe[1], fileno(stdout));
				}
				if (processCount >= 1)
				{
					dup2(prevPipe[0], fileno(stdin));
					close(prevPipe[0]);
					close(prevPipe[1]);
				}
				else
				{
					close(fileno(stdin));
				}

				execv(process[0], process);
			}
			else
			{
				if (processCount >= 1)
				{
					close(prevPipe[0]);
					close(prevPipe[1]);
				}

				if (processCount >= (serviceList[serviceCount].count - 1))
				{
					realloc(serviceList[serviceCount].processList, INITIAL_NO_PROCESS * 2 * sizeof(sm_status_t));
					serviceList[serviceCount].count = INITIAL_NO_PROCESS * 2;
				}

				serviceList[serviceCount].processList[processCount].pid = pid;
				serviceList[serviceCount].processList[processCount].running = 1;
				serviceList[serviceCount].processList[processCount].path = strdup(process[0]);
				free(process);
				if (isLast)
				{
					serviceCount++;
					break;
				}
				else
				{
					process = (char **)calloc(INITIAL_ARG_SIZE, sizeof(char));
					start = 0;
					processCount++;
					prevPipe[0] = curPipe[0];
					prevPipe[1] = curPipe[1];
				}
			}
		}
		else
		{
			//Need one extra for NULL which is assigned in above if
			if (start >= (INITIAL_ARG_SIZE - 1))
			{
				realloc(process, INITIAL_ARG_SIZE * 2);
			}
			process[start] = processes[pNo];
			start++;
		}
	}
}

// Exercise 1b: print service status
size_t sm_status(sm_status_t statuses[])
{
	int i, j = 0;
	for (i = 0; i < serviceCount; i++)
	{
		j = 0;

		//traverse to last process
		while (j < serviceList[i].count)
		{
			if (serviceList[i].processList[j].pid == 0)
			{
				break;
			}
			j++;
		}

		statuses[i].path = strdup(serviceList[i].processList[j - 1].path);
		statuses[i].pid = serviceList[i].processList[j - 1].pid;
		statuses[i].running = waitpid(serviceList[i].processList[j - 1].pid, NULL, WNOHANG) ? 0 : 1;
	}
	return serviceCount;
}

// Exercise 3: stop service, wait on service, and shutdown
void sm_stop(size_t index)
{
	serviceLog_t service = serviceList[index];
	int i = 0;
	for (; (i < service.count && service.processList[i].pid != 0); i++)
	{
		if (!waitpid(service.processList[i].pid, NULL, WNOHANG))
		{
			kill(service.processList[i].pid, SIGTERM);
		}
	}

	for (; (i < service.count && service.processList[i].pid != 0); i++)
	{
		waitpid(service.processList[i].pid, NULL, 0);
	}
}

void sm_wait(size_t index)
{
	serviceLog_t service = serviceList[index];
	int i = 0;
	for (; (i < service.count && service.processList[i].pid != 0); i++)
	{
		waitpid(service.processList[i].pid, NULL, 0);
	}
}

void sm_shutdown(void)
{
	int i = 0;
	for (; i < SM_MAX_SERVICES; i++)
	{
		sm_stop(i);
	}
}

// Exercise 4: start with output redirection
void sm_startlog(const char *processes[])
{
}

// Exercise 5: show serviceLog file
void sm_showlog(size_t index)
{
}
