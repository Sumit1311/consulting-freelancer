/*************************************
* Lab 4
* Name:
* Student No:
* Lab Group:
*************************************/

#include "shmheap.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

shmheap_memory_handle shmheap_create(const char *name, size_t len)
{
    /* TODO */
    int fd = shm_open(name, O_RDWR | O_CREAT, S_IRWXG | S_IRWXO | S_IRWXU);
    void *addr;
    //shmheap_memory_handle *handle = malloc(sizeof(shmheap_memory_handle));
    shmheap_memory_handle handle;

    if (fd == -1)
    {
        printf("Failed to create %s\n", name);
        return;
    }

    ftruncate(fd, len);

    if ((addr = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0)) == MAP_FAILED)
    {
        printf("Mapping Failed\n");
        return;
    }

    handle.fd = fd;
    handle.heap_start = addr;
    handle.size = len;
    handle.allocated_size = 0;

    /*handle->fd = fd;
    handle->heap_start = addr;
    handle->size = len;
    handle->allocated_size = 0;*/

    //return *handle;
    return handle;
}

shmheap_memory_handle shmheap_connect(const char *name)
{
    /* TODO */
    int fd = shm_open(name, O_RDWR, S_IRWXG | S_IRWXO | S_IRWXU);
    void *addr;
    struct stat sb;
    //shmheap_memory_handle *handle = malloc(sizeof(shmheap_memory_handle));
    shmheap_memory_handle handle;
    if (fd == -1)
    {
        printf("Failed to create %s\n", name);
        return;
    }

    if (fstat(fd, &sb) == -1)
    {
        printf("Failed fstat %s\n", name);
        return;
    }

    if ((addr = mmap(NULL, sb.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0)) == MAP_FAILED)
    {
        printf("Mapping Failed\n");
        return;
    }

    handle.fd = fd;
    handle.heap_start = addr;
    handle.size = sb.st_size;
    handle.allocated_size = 0;

    return handle;

    /*handle->fd = fd;
    handle->heap_start = addr;
    handle->size = sb.st_size;
    handle->allocated_size = 0;

    return *handle;*/
}

void shmheap_disconnect(shmheap_memory_handle mem)
{
    /* TODO */
    munmap(mem.heap_start, mem.size);
    close(mem.fd);
}

void shmheap_destroy(const char *name, shmheap_memory_handle mem)
{
    /* TODO */
    munmap(mem.heap_start, mem.size);
    close(mem.fd);
    shm_unlink(name);
}

void *shmheap_underlying(shmheap_memory_handle mem)
{
    /* TODO */
}

void *shmheap_alloc(shmheap_memory_handle mem, size_t sz)
{
    /* TODO */
    void *addr;
    addr = (void *)(mem.heap_start + mem.allocated_size);
    mem.allocated_size += sz;
    return addr;
}

void shmheap_free(shmheap_memory_handle mem, void *ptr)
{
    /* TODO */
}

shmheap_object_handle shmheap_ptr_to_handle(shmheap_memory_handle mem, void *ptr)
{
    /* TODO */
    shmheap_object_handle handle;
    size_t offset = ptr - (void *)mem.heap_start;
    handle.offset = offset;
    return handle;
}

void *shmheap_handle_to_ptr(shmheap_memory_handle mem, shmheap_object_handle hdl)
{
    /* TODO */
    void *address = mem.heap_start + hdl.offset;
    return address;
}
