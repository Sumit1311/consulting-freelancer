/**
 * CS2106 AY 20/21 Semester 1 - Lab 3
 *
 * Your implementation should go in this file.
 */
#include "entry_controller.h"

void entry_controller_init( entry_controller_t *entry_controller, int loading_bays ) {
}

void entry_controller_wait( entry_controller_t *entry_controller ) {
}

void entry_controller_post( entry_controller_t *entry_controller ) {
}

void entry_controller_destroy( entry_controller_t *entry_controller ) {
}

