/**
 * CS2106 AY 20/21 Semester 1 - Lab 3
 *
 * Your implementation should go in this file.
 */
#include "fizzbuzz_workers.h"
#include "barrier.h" // you may use barriers if you think it can help your
                     // implementation

// declare variables to be used here

void fizzbuzz_init ( int n ) {
}

void num_thread( int n, void (*print_num)(int) ) {
}

void fizz_thread( int n, void (*print_fizz)(void) ) {
}

void buzz_thread( int n, void (*print_buzz)(void) ) {
}

void fizzbuzz_thread( int n, void (*print_fizzbuzz)(void) ) {
}

void fizzbuzz_destroy() {
}
